export const ITEM_TYPES = [
  'note',
  'text',
  'personal',
  'credential',
  'image',
  'file',
  'link',
  'custom',
] as const;

export type ItemType = (typeof ITEM_TYPES)[number];

export interface CustomField {
  readonly id: string;
  readonly label: string;
  readonly value: string;
  /** Rendered masked in the UI and excluded from previews. */
  readonly secret: boolean;
}

export interface AttachmentMeta {
  readonly blobId: string;
  readonly name: string;
  readonly mime: string;
  readonly size: number;
  readonly addedAt: number;
  readonly chunks: number;
}

/**
 * Lightweight, searchable projection of an item.
 * Encrypted at rest; decrypted for the whole vault on unlock (small payloads)
 * so search stays instant without decrypting bodies or files.
 */
export interface ItemIndexEntry {
  readonly title: string;
  readonly type: ItemType;
  readonly category: string | null;
  readonly tags: string[];
  /** Short, non-secret excerpt used in lists. Never contains secret fields. */
  readonly preview: string;
  readonly attachmentCount: number;
  readonly favorite: boolean;
}

/** Heavy part of an item. Decrypted only when the item is opened. */
export interface ItemContent {
  readonly body: string;
  readonly fields: CustomField[];
  readonly attachments: AttachmentMeta[];
  readonly url: string | null;
}

export interface VaultItem extends ItemIndexEntry, ItemContent {
  readonly id: string;
  readonly createdAt: number;
  readonly updatedAt: number;
  readonly deletedAt: number | null;
}

export type ItemSummary = ItemIndexEntry & {
  readonly id: string;
  readonly createdAt: number;
  readonly updatedAt: number;
  readonly deletedAt: number | null;
};

export interface ItemDraft {
  title: string;
  type: ItemType;
  category?: string | null;
  tags?: string[];
  body?: string;
  fields?: CustomField[];
  url?: string | null;
  favorite?: boolean;
}

export type ThemeMode = 'system' | 'dark' | 'light';
export type Language = 'fa' | 'en';

export interface Settings {
  readonly autoLockMs: number;
  readonly lockOnBackground: boolean;
  readonly theme: ThemeMode;
  readonly language: Language;
  readonly clipboardClearSeconds: number;
  readonly showPreviews: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  autoLockMs: 5 * 60_000,
  lockOnBackground: true,
  theme: 'system',
  language: 'fa',
  clipboardClearSeconds: 30,
  showPreviews: true,
};

export const AUTO_LOCK_PRESETS_MS = [0, 60_000, 5 * 60_000, 15 * 60_000, 30 * 60_000, 60 * 60_000] as const;

export interface VaultStatus {
  readonly exists: boolean;
  readonly unlocked: boolean;
  readonly itemCount: number;
  readonly trashCount: number;
  readonly lastUnlockAt: number | null;
  readonly createdAt: number | null;
}
