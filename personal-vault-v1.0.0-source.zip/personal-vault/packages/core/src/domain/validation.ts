import { ITEM_TYPES, type ItemDraft, type ItemType } from './types.ts';
import { VaultError } from './errors.ts';

export const LIMITS = {
  titleMax: 200,
  bodyMax: 200_000,
  tagMax: 40,
  tagsMax: 32,
  fieldsMax: 64,
  fieldLabelMax: 80,
  fieldValueMax: 8_000,
  fileMaxBytes: 25 * 1024 * 1024,
  previewMax: 140,
} as const;

function str(value: unknown): string {
  return typeof value === 'string' ? value : '';
}

export function isItemType(value: unknown): value is ItemType {
  return typeof value === 'string' && (ITEM_TYPES as readonly string[]).includes(value);
}

/** Normalizes a draft and throws VALIDATION_FAILED on anything we refuse to store. */
export function normalizeDraft(draft: ItemDraft): Required<Omit<ItemDraft, 'category' | 'url'>> & {
  category: string | null;
  url: string | null;
} {
  const title = str(draft.title).trim();
  if (!title) throw new VaultError('VALIDATION_FAILED', 'title is required');
  if (title.length > LIMITS.titleMax) throw new VaultError('VALIDATION_FAILED', 'title too long');
  if (!isItemType(draft.type)) throw new VaultError('VALIDATION_FAILED', 'unknown item type');

  const body = str(draft.body);
  if (body.length > LIMITS.bodyMax) throw new VaultError('VALIDATION_FAILED', 'body too long');

  const tags = (draft.tags ?? [])
    .map((t) => str(t).trim())
    .filter((t, i, all) => t.length > 0 && t.length <= LIMITS.tagMax && all.indexOf(t) === i)
    .slice(0, LIMITS.tagsMax);

  const fields = (draft.fields ?? []).slice(0, LIMITS.fieldsMax).map((f, i) => {
    const label = str(f?.label).trim().slice(0, LIMITS.fieldLabelMax);
    const value = str(f?.value).slice(0, LIMITS.fieldValueMax);
    return { id: str(f?.id) || `f${i}`, label, value, secret: Boolean(f?.secret) };
  });

  const category = draft.category ? str(draft.category).trim().slice(0, LIMITS.tagMax) : null;

  let url: string | null = null;
  if (draft.url) {
    const raw = str(draft.url).trim();
    try {
      const parsed = new URL(raw);
      if (!['http:', 'https:', 'mailto:'].includes(parsed.protocol)) {
        throw new VaultError('VALIDATION_FAILED', 'unsupported url scheme');
      }
      url = parsed.toString();
    } catch {
      throw new VaultError('VALIDATION_FAILED', 'invalid url');
    }
  }

  return { title, type: draft.type, category, tags, body, fields, url, favorite: Boolean(draft.favorite) };
}

/** Preview text never includes values of secret fields. */
export function buildPreview(body: string, fields: { value: string; secret: boolean }[]): string {
  const source = body.trim() || fields.find((f) => !f.secret)?.value?.trim() || '';
  return source.replace(/\s+/g, ' ').slice(0, LIMITS.previewMax);
}
