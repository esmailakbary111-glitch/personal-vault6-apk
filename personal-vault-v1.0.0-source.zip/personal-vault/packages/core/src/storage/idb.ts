/**
 * Minimal promise wrapper over IndexedDB.
 *
 * Why not the `idb` package: the vault needs explicit, short-lived
 * transactions (see docs/ARCHITECTURE.md — no await of crypto inside an open
 * transaction). A ~120 line wrapper keeps @pv/core dependency-free, makes the
 * transaction boundaries visible in review, and runs unchanged in browsers,
 * MV3 service workers and the Android WebView.
 */

export type TxMode = 'readonly' | 'readwrite';

export function requestToPromise<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('IDBRequestFailed'));
  });
}

export function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error('IDBTransactionFailed'));
    tx.onabort = () => reject(tx.error ?? new Error('IDBTransactionAborted'));
  });
}

/**
 * Runs `fn` inside one transaction and resolves after it commits.
 * `fn` must be synchronous in its IndexedDB calls: it may build requests, but
 * must not await anything unrelated, otherwise the transaction auto-closes.
 */
export async function runTx<T>(
  db: IDBDatabase,
  stores: string[],
  mode: TxMode,
  fn: (tx: IDBTransaction) => T | Promise<T>,
): Promise<T> {
  const tx = db.transaction(stores, mode);
  const done = txDone(tx);
  let result: T;
  try {
    result = await fn(tx);
  } catch (error) {
    try { tx.abort(); } catch { /* already finished */ }
    throw error;
  }
  await done;
  return result;
}

export async function getAllFromIndex<T>(
  tx: IDBTransaction,
  store: string,
  indexName: string,
  query?: IDBKeyRange | IDBValidKey,
): Promise<T[]> {
  const idx = tx.objectStore(store).index(indexName);
  return requestToPromise(idx.getAll(query as IDBValidKey) as IDBRequest<T[]>);
}
