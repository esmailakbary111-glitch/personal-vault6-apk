import type { Envelope, Keyring } from '@pv/crypto';

/** Bump with every structural change and add a migration step. */
export const DB_VERSION = 1;
export const DB_NAME = 'personal-vault';

export const STORE = {
  meta: 'meta',
  items: 'items',
  blobs: 'blobs',
  settings: 'settings',
  /** Write-ahead area used by restore; never read by the normal app paths. */
  staging: 'staging',
} as const;

export const META_KEY = 'vault' as const;

export interface VaultMetaRecord {
  readonly key: typeof META_KEY;
  readonly schemaVersion: number;
  readonly appVersion: string;
  readonly keyring: Keyring;
  readonly createdAt: number;
  readonly updatedAt: number;
}

export interface AttachmentRef {
  readonly blobId: string;
  readonly size: number;
  readonly chunks: number;
}

/**
 * At-rest item record. Only non-sensitive scheduling fields are plaintext:
 * identifiers, timestamps and byte sizes. Title, type, category, tags,
 * preview, body, field values and file names all live inside the envelopes.
 */
export interface ItemRecord {
  readonly id: string;
  readonly createdAt: number;
  readonly updatedAt: number;
  /** null = live, number = moved to trash at this timestamp */
  readonly deletedAt: number | null;
  readonly indexEnv: Envelope;
  readonly contentEnv: Envelope;
  readonly attachments: AttachmentRef[];
}

export interface BlobChunkRecord {
  readonly blobId: string;
  readonly chunk: number;
  readonly itemId: string;
  readonly env: Envelope;
}

export interface SettingsRecord {
  readonly key: string;
  readonly value: unknown;
}

export interface StagingRecord {
  readonly key: string;
  readonly value: unknown;
}

type Migration = (db: IDBDatabase, tx: IDBTransaction) => void;

/**
 * Forward migrations only, applied in order for the range the browser reports.
 * Each step must be safe to run on a vault that holds real data: create
 * stores/indexes, never drop or rewrite user records destructively.
 */
export const MIGRATIONS: Record<number, Migration> = {
  1: (db) => {
    db.createObjectStore(STORE.meta, { keyPath: 'key' });

    const items = db.createObjectStore(STORE.items, { keyPath: 'id' });
    items.createIndex('by_updatedAt', 'updatedAt');
    items.createIndex('by_createdAt', 'createdAt');
    // deletedAt is nullable; IndexedDB skips null keys, so this index contains
    // exactly the trashed items — which is what the Trash screen needs.
    items.createIndex('by_deletedAt', 'deletedAt');

    const blobs = db.createObjectStore(STORE.blobs, { keyPath: ['blobId', 'chunk'] });
    blobs.createIndex('by_blobId', 'blobId');
    blobs.createIndex('by_itemId', 'itemId');

    db.createObjectStore(STORE.settings, { keyPath: 'key' });
    db.createObjectStore(STORE.staging, { keyPath: 'key' });
  },
};

export function applyMigrations(db: IDBDatabase, tx: IDBTransaction, from: number, to: number): void {
  for (let version = from + 1; version <= to; version += 1) {
    const step = MIGRATIONS[version];
    if (!step) throw new Error(`UNSUPPORTED_MIGRATION: no step for db version ${version}`);
    step(db, tx);
  }
}
