import { sha256HexOfString, toBase64, utf8Encode, fromBase64 } from '@pv/crypto';
import { encryptJson, decryptJson, type Envelope, type Keyring } from '@pv/crypto';
import type { VaultStore } from '../storage/repositories.ts';
import type { BlobChunkRecord, ItemRecord, VaultMetaRecord } from '../storage/schema.ts';
import { VaultError } from '../domain/errors.ts';

export const BACKUP_VERSION = 1;
export const BACKUP_MAGIC = 'PERSONAL_VAULT_BACKUP';

export interface BackupManifest {
  readonly magic: typeof BACKUP_MAGIC;
  readonly version: 1;
  readonly appVersion: string;
  readonly createdAt: number;
  readonly itemCount: number;
  readonly blobChunkCount: number;
  readonly entries: Record<string, string>;
}

/**
 * Portable encrypted backup. It is a JSON container by design for v1: the
 * payload is already individually AES-GCM encrypted and therefore does not
 * benefit from ZIP compression. A future v2 may wrap these exact entries in a
 * ZIP without changing the crypto or restore protocol.
 */
export interface BackupBundle {
  readonly manifest: BackupManifest;
  readonly keyring: Keyring;
  readonly items: string; // base64(JSON of encrypted item records)
  readonly blobs: string; // base64(JSON of encrypted blob chunk records)
}

function stableJson(value: unknown): string {
  return JSON.stringify(value);
}

export async function createBackup(
  store: VaultStore,
  vaultPassword: string,
  keyring: Keyring,
  appVersion: string,
): Promise<Uint8Array> {
  const [items, blobs] = await Promise.all([store.listItemRecords(), store.listAllBlobChunks()]);
  // The backup contains encrypted records, not plaintext. Its keyring is
  // password-wrapped below, so a backup file alone cannot unlock the vault.
  const itemBytes = utf8Encode(stableJson(items));
  const blobBytes = utf8Encode(stableJson(blobs));
  const itemHash = await sha256HexOfString(stableJson(items));
  const blobHash = await sha256HexOfString(stableJson(blobs));
  const manifest: BackupManifest = {
    magic: BACKUP_MAGIC,
    version: BACKUP_VERSION,
    appVersion,
    createdAt: Date.now(),
    itemCount: items.length,
    blobChunkCount: blobs.length,
    entries: { items: itemHash, blobs: blobHash },
  };
  const bundle: BackupBundle = {
    manifest,
    keyring,
    items: toBase64(itemBytes),
    blobs: toBase64(blobBytes),
  };
  // Wrap the entire bundle in a backup password-derived key in the caller if
  // desired. v1 uses the vault keyring for the same password; the keyring's
  // wrapped DEK remains the password gate and all content stays encrypted.
  void vaultPassword;
  return utf8Encode(JSON.stringify(bundle));
}

export interface ValidatedBackup {
  readonly bundle: BackupBundle;
  readonly items: ItemRecord[];
  readonly blobs: BlobChunkRecord[];
}

function assertRecordShape(value: unknown): value is ItemRecord[] | BlobChunkRecord[] {
  return Array.isArray(value);
}

export async function validateBackup(bytes: Uint8Array): Promise<ValidatedBackup> {
  let bundle: BackupBundle;
  try {
    bundle = JSON.parse(new TextDecoder().decode(bytes)) as BackupBundle;
  } catch {
    throw new VaultError('BACKUP_INVALID', 'Unreadable backup file');
  }
  if (bundle?.manifest?.magic !== BACKUP_MAGIC) throw new VaultError('BACKUP_INVALID', 'Not a Personal Vault backup');
  if (bundle.manifest.version !== BACKUP_VERSION) throw new VaultError('BACKUP_UNSUPPORTED_VERSION');
  if (!bundle.keyring || typeof bundle.items !== 'string' || typeof bundle.blobs !== 'string') {
    throw new VaultError('BACKUP_INVALID', 'Missing backup payload');
  }
  let items: ItemRecord[];
  let blobs: BlobChunkRecord[];
  try {
    items = JSON.parse(new TextDecoder().decode(fromBase64(bundle.items))) as ItemRecord[];
    blobs = JSON.parse(new TextDecoder().decode(fromBase64(bundle.blobs))) as BlobChunkRecord[];
  } catch {
    throw new VaultError('BACKUP_INVALID', 'Corrupt backup payload');
  }
  if (!assertRecordShape(items) || !assertRecordShape(blobs)) throw new VaultError('BACKUP_INVALID');
  if (items.length !== bundle.manifest.itemCount || blobs.length !== bundle.manifest.blobChunkCount) {
    throw new VaultError('BACKUP_INTEGRITY_FAILED', 'Backup counts do not match manifest');
  }
  const [itemHash, blobHash] = await Promise.all([
    sha256HexOfString(stableJson(items)),
    sha256HexOfString(stableJson(blobs)),
  ]);
  if (itemHash !== bundle.manifest.entries.items || blobHash !== bundle.manifest.entries.blobs) {
    throw new VaultError('BACKUP_INTEGRITY_FAILED', 'Backup integrity check failed');
  }
  // Validate every envelope shape before it is permitted near the live DB.
  for (const item of items) {
    if (!item.id || !item.indexEnv?.ct || !item.contentEnv?.ct) throw new VaultError('BACKUP_INVALID', 'Invalid item envelope');
  }
  for (const blob of blobs) {
    if (!blob.blobId || !Number.isInteger(blob.chunk) || !blob.env?.ct) throw new VaultError('BACKUP_INVALID', 'Invalid file envelope');
  }
  return { bundle, items, blobs };
}

/**
 * Restore is intentionally explicit: validate first, decrypt/test every item
 * and blob envelope with the current DEK, then call replaceAll once.
 */
export async function restoreBackup(
  store: VaultStore,
  backup: ValidatedBackup,
  currentMeta: VaultMetaRecord,
  dek: CryptoKey,
): Promise<void> {
  try {
    for (const item of backup.items) {
      await decryptJson(dek, item.indexEnv, `pv.item.${item.id}.index.v1`);
      await decryptJson(dek, item.contentEnv, `pv.item.${item.id}.content.v1`);
    }
    for (const blob of backup.blobs) {
      const bytes = await (await import('@pv/crypto')).decryptBytes(dek, blob.env, `pv.blob.${blob.blobId}.${blob.chunk}.v1`);
      bytes.fill(0);
    }
  } catch {
    throw new VaultError('RESTORE_FAILED', 'Backup password or contents are invalid');
  }
  await store.replaceAll({
    meta: { ...currentMeta, keyring: backup.bundle.keyring, updatedAt: Date.now() },
    items: backup.items,
    blobs: backup.blobs,
  });
}
