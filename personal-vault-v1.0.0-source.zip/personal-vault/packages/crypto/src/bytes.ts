/**
 * Byte / encoding helpers. No crypto primitives live here.
 */

const encoder = new TextEncoder();
const decoder = new TextDecoder();

export function utf8Encode(value: string): Uint8Array {
  return encoder.encode(value);
}

export function utf8Decode(bytes: Uint8Array): string {
  return decoder.decode(bytes);
}

export function concatBytes(...parts: Uint8Array[]): Uint8Array {
  const total = parts.reduce((sum, p) => sum + p.byteLength, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.byteLength;
  }
  return out;
}

export function toBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  // btoa exists in browsers, extension workers and Node >= 16.
  return btoa(binary);
}

export function fromBase64(value: string): Uint8Array {
  const binary = atob(value);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) out[i] = binary.charCodeAt(i);
  return out;
}

export function toHex(bytes: Uint8Array): string {
  let out = '';
  for (const b of bytes) out += b.toString(16).padStart(2, '0');
  return out;
}

/**
 * Length-aware, value-independent comparison. Used for integrity digests so
 * that comparison time does not leak how much of a digest matched.
 */
export function timingSafeEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.byteLength !== b.byteLength) return false;
  let diff = 0;
  for (let i = 0; i < a.byteLength; i += 1) diff |= (a[i] as number) ^ (b[i] as number);
  return diff === 0;
}

/**
 * Best-effort overwrite of a byte buffer.
 *
 * HONEST LIMITATION: JavaScript engines may keep copies of data we cannot
 * reach (string interning, GC-moved buffers, JIT temporaries). Wiping a
 * TypedArray reduces the window in which plaintext is readable; it is not a
 * guarantee that no copy remains in process memory.
 */
export function wipe(...buffers: Array<Uint8Array | undefined | null>): void {
  for (const buf of buffers) {
    if (buf && buf.byteLength > 0) buf.fill(0);
  }
}
