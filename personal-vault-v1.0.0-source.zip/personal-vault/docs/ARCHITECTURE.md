# Personal Vault architecture

## Runtime layers

`UI -> Zustand application state -> @pv/core application/domain -> @pv/crypto -> IndexedDB`

The Chrome Extension and Android shell both load the same bundled React web application. The extension shell is a minimal MV3 manifest with no remote code. Android uses `WebViewAssetLoader` and `https://appassets.androidplatform.net/assets/index.html`; there is no localhost server, loopback URL, or cleartext HTTP.

## At-rest model

The vault has a random 256-bit DEK. A master password derives a non-extractable AES-GCM KEK with PBKDF2-SHA-256 and a per-vault 16-byte salt at 600,000 iterations. The KEK wraps the DEK. Every item index, item body, and 256 KiB file chunk gets a fresh 96-bit AES-GCM nonce and AAD binding it to its record identity.

Only IDs, timestamps, deletedAt, and file byte/chunk counts are plaintext in IndexedDB. Searchable projections are encrypted and decrypted only after unlock. Bodies and files are lazy.

## Transaction rule

Crypto happens before IndexedDB write transactions. A write transaction only puts prepared ciphertext or clears/swaps already validated records. Restore verifies structure, version, every manifest hash, every item envelope, and every blob envelope before a single atomic replace transaction.

## Honest limitations

JavaScript cannot guarantee physical memory erasure because the engine may copy strings/buffers. Personal Vault drops all CryptoKey and decrypted projection references on lock and best-effort wipes byte arrays, but does not claim impossible guarantees.
