# Security notes

- No password, raw key, or plaintext vault data is logged in production.
- AES-GCM authentication detects modified ciphertext. Wrong password and modified keyring are intentionally not distinguished in user copy.
- PBKDF2 is used because it is native in Web Crypto across Chrome MV3 and Android WebView. Argon2id can be added behind the same KDF interface if a reviewed WASM path is introduced.
- Backups are encrypted records, not plaintext exports. Validate and decrypt/test all payloads before restore.
- Lost password recovery is intentionally not available without an independent backup password/recovery key. This is the price of local-first encryption.
