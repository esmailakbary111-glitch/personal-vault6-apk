import test from 'node:test'; import assert from 'node:assert/strict'; import { webcrypto } from 'node:crypto';
if (!globalThis.crypto) Object.defineProperty(globalThis, 'crypto', { value: webcrypto, configurable: true });
const c=await import('../../packages/crypto/src/index.ts');
test('key hierarchy and AES-GCM roundtrip',async()=>{const {keyring,dek}=await c.createKeyring('Correct-Horse-42'); const env=await c.encryptJson(dek,{secret:'local'},'pv.test'); assert.deepEqual(await c.decryptJson(dek,env,'pv.test'),{secret:'local'}); await assert.rejects(()=>c.decryptJson(dek,env,'wrong'),e=>e.code==='DATA_TAMPERED'); const dek2=await c.unlockKeyring('Correct-Horse-42',keyring); assert.deepEqual(await c.decryptJson(dek2,env,'pv.test'),{secret:'local'});});
test('wrong password and tamper are rejected',async()=>{const {keyring}=await c.createKeyring('Correct-Horse-42'); await assert.rejects(()=>c.unlockKeyring('nope-pass-22',keyring),e=>e.code==='WRONG_PASSWORD');});
