import { defineConfig } from 'vite'; import react from '@vitejs/plugin-react';
export default defineConfig({ plugins:[react()], resolve:{alias:{'@pv/core':'/packages/core/src','@pv/crypto':'/packages/crypto/src','@pv/ui':'/packages/ui/src'}}, build:{sourcemap:false} });
